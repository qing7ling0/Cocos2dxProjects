#include "HelloWorldScene.h"
#include "net/socket/RecvThread.h"
#include "net/socket/SendThread.h"
#include "net/socket/ODSocket.h"
#include "net/SocketConn.h"
#include "tools/debug/Debug.h"
#include "net\Packet.h"

USING_NS_CC;

Scene* HelloWorld::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    
    // 'layer' is an autorelease object
    auto layer = HelloWorld::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

// on "init" you need to initialize your instance
bool HelloWorld::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !Layer::init() )
    {
        return false;
    }
    
    Size visibleSize = Director::getInstance()->getVisibleSize();
    Point origin = Director::getInstance()->getVisibleOrigin();

    /////////////////////////////
    // 2. add a menu item with "X" image, which is clicked to quit the program
    //    you may modify it.

    // add a "close" icon to exit the progress. it's an autorelease object
    auto closeItem = MenuItemImage::create(
                                           "CloseNormal.png",
                                           "CloseSelected.png",
                                           CC_CALLBACK_1(HelloWorld::menuCloseCallback, this));
    
	closeItem->setPosition(Point(origin.x + visibleSize.width - closeItem->getContentSize().width/2 ,
                                origin.y + closeItem->getContentSize().height/2));

    auto webItem = MenuItemImage::create(
                                           "CloseNormal.png",
                                           "CloseSelected.png",
                                           CC_CALLBACK_1(HelloWorld::menuNetCallback, this));
    
	webItem->setPosition(Point(origin.x + visibleSize.width/2 - closeItem->getContentSize().width/2 ,
                                origin.y + closeItem->getContentSize().height/2));

    auto threadItem = MenuItemImage::create(
                                           "CloseNormal.png",
                                           "CloseSelected.png",
                                           CC_CALLBACK_1(HelloWorld::menuThreadCallback, this));
    
	threadItem->setPosition(Point(origin.x + visibleSize.width/4 - closeItem->getContentSize().width/2 ,
                                origin.y + closeItem->getContentSize().height/2));

    // create menu, it's an autorelease object
    auto menu = Menu::create(closeItem, webItem, threadItem, NULL);
    menu->setPosition(Point::ZERO);
    this->addChild(menu, 1);

    /////////////////////////////
    // 3. add your codes below...

    // add a label shows "Hello World"
    // create and initialize a label
    
    auto label = LabelTTF::create("Hello World", "Arial", 24);
    
    // position the label on the center of the screen
    label->setPosition(Point(origin.x + visibleSize.width/2,
                            origin.y + visibleSize.height - label->getContentSize().height));

    // add the label as a child to this layer
    this->addChild(label, 1);
    
    auto web = LabelTTF::create("websocket", "Arial", 40);
    
    // position the label on the center of the screen
    web->setPosition(Point(origin.x + visibleSize.width/2,
                            origin.y + visibleSize.height/2 - label->getContentSize().height));

    // add the label as a child to this layer
    this->addChild(web, 1);

    // add "HelloWorld" splash screen"
    auto sprite = Sprite::create("HelloWorld.png");

    // position the sprite on the center of the screen
    sprite->setPosition(Point(visibleSize.width/2 + origin.x, visibleSize.height/2 + origin.y));

    // add the sprite as a child to this layer
    this->addChild(sprite, 0);
    

	/*socket = new QSocket();
	socket->connect("61.147.117.149", 6666);


	
	socket->write("", 1);*/

	/*SOCKET s = 2;

	ODSocket *os = new ODSocket(s);*/
	
	/*RecvThread *rt = new RecvThread(NULL);
	rt->start();

	SendThread *st = new SendThread(NULL);
	st->start();*/

	SocketConn::create();
	s_thread = nullptr;

    return true;
}


void HelloWorld::menuCloseCallback(Object* pSender)
{
	SocketConn::clean();
    Director::getInstance()->end();

#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
    exit(0);
#endif
}

void HelloWorld::menuThreadCallback(Object* pSender)
{
	if (s_thread)
	{
		if (threadStart)
		{
			s_thread->stop();
			threadStart = false;
		}
		else
		{
			s_thread->start();
			threadStart = true;
		}
	}
	else
	{
		s_thread = new SocketThread(NULL);
		s_thread->start();
		threadStart = true;
	}
}

void HelloWorld::menuNetCallback(Object* pSender)
{
	SocketConn::getInstance()->openConn("61.147.117.149", 6666);
	QLog("net work contact!");

	Packet* p = new Packet();
	p->id = 20;
	p->setType(0x00f2);
	p->enter(-20);
	string str("HH");
	p->enter(str);
	p->enter((short)-3000);
	p->enter((q_byte)-21);
	p->enter(true);
	p->setPointer(0);

	Packet* p2 = new Packet();
	p2->setType(0x00f2);
	SocketConn::getInstance()->send(p2);
	
	int temp = p->decodeInt();
	string st = p->decodeString();
	short sh = p->decodeShort();
	q_byte by = p->decodeByte();
	bool bl = p->decodeBoolean();
	
	CCLog("id=%d, temp=%d, str=%s", p->id, temp, st.c_str());
	
	CCLog("short=%d, byte=%d", sh, by);

	if (bl)
	{
		CCLog("boolean=true");
	}
	else
	{
		CCLog("boolean=false");
	}
}
