#ifndef __PLATFORM__
#define __PLATFORM__

typedef char q_byte;

#define CHAR_LENGTH sizeof(char)

#endif