#include "BaseResponseMsg.h"
BaseResponseMsg::BaseResponseMsg(void){
	this->state=0;
}
BaseResponseMsg::~BaseResponseMsg(void){

}