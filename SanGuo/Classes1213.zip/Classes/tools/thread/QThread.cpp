#include "QThread.h"


QThread::QThread(std::function<void (void)> fun)
{
	runF = std::bind(fun);
}

int QThread::start(){    	
	int errCode = 0;
	do{
		pthread_attr_t tAttr;
		errCode = pthread_attr_init(&tAttr);
		if (errCode!=0) {
			break;
		}		
		//���������������������������ҪΪ�㴴�����߳��趨Ϊ����ʽ
		errCode = pthread_attr_setdetachstate(&tAttr, PTHREAD_CREATE_DETACHED);
		if (errCode!=0) {
			pthread_attr_destroy(&tAttr);
			break;
		}		
		errCode = pthread_create(&pid,&tAttr,start_thread, this);
	}while (0);
	return errCode;
} 


void* QThread::start_thread(void *arg)   {

	QThread* thread= (QThread*)arg;
	thread->runF();
	return NULL;                                                                                    
}

void QThread::stop(){
	pthread_cancel(pid);
	pthread_detach(pid);
}

QThread::~QThread(void)
{
}
