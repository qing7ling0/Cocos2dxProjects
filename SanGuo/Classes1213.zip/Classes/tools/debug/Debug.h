#pragma once
#include <string>
#include "./common/QCommon.h"


class Debug
{
public:
	Debug(void);
	virtual ~Debug(void);
	
	static void log(std::string info, ...);
};

